import sqlite3
Books=sqlite3.connect("books.db")
curbooks=Books.cursor()
books_cost=0
def cost():
    global books_cost
    name=input("Book Title :  ")
    sql="SELECT * from books where Title='"+name+"';"
    curbooks.execute(sql)
    record=curbooks.fetchone()
    print(record)
    print()
    copies=int(input("No. of copies : "))
    Y_N=input("Add more books? Y/N :  ")
    if Y_N=='Y':
        books_cost+= record[3]*copies
        cost()
    else:
        books_cost+= record[3]*copies
cost()
print("Total Cost",books_cost)


