import sqlite3
Books=sqlite3.connect('books.db')
curbooks=Books.cursor()
curbooks.execute('''create table books (
BookID Integer Primary key autoincrement,
Title varchar(25),
author varchar(20),
price real);''')
curbooks.execute('''Insert into books values(1,"Introducation to Algorithms",
"Thomas H. Cormen",350);''')
curbooks.execute('''Insert into books values(2,"The Pragmatic Programmer",
"Andrew Hunt",400);''')
curbooks.execute('''Insert into books values(3,"Design Patterns",
"Erich Gamma",280);''')
curbooks.execute('''Insert into books values(4,"Code Complete",
"Steve McConnell",500);''')
curbooks.execute('''Insert into books values(5,"Refactoring:Improve design",
"Martin Fowler",450);''')
curbooks.execute('''Insert into books values(6,"Algorithms",
"Robert Sedgewick",350);''')
curbooks.execute('''Insert into books values(7,"Rapid Development",
"Steve McConnell",250);''')
curbooks.execute('''Insert into books values(8,"Domain-Driven Design",
"Eric Evans",300);''')
curbooks.execute('''Insert into books values(9,"Peopleware",
"Tom DeMarco",500);''')
curbooks.execute('''Insert into books values(10,"Soft Skills",
"John Sonmez",280);''')
Books.commit()
Books.close()

