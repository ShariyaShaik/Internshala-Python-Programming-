def batting(batsman):
    batscore=0
    runs_points=(batsman['runs']/2)
    if batsman['runs']>=50:
        runs_points+=5
    if batsman['runs']>=100:
        runs_points+=10
    batscore+=runs_points
    strike_rate=(batsman['runs']/batsman['balls'])*100
    if strike_rate>=80 and strike_rate<=100:
        batscore+=2
    elif strike_rate>100:
        batscore+=4
    else:
        pass
    batscore+=(batsman['4']*1)+(batsman['6']*2)
    result={'name':batsman['name'],'batscore':int(batscore)}
    return result
def bowling(bowler):
    bowlscore=0
    if bowler['wkts']>=3:
        bowlscore+=5
    if bowler['wkts']>=5:
        bowlscore+=10
    bowlscore+=bowler['wkts']*10
    economy_rate=bowler['runs']/bowler['overs']
    if economy_rate>=3.5 and economy_rate<=4.5:
        bowlscore+=4
    elif economy_rate>=2 and economy_rate<3.5:
        bowlscore+=7
    elif economy_rate<2:
        bowlscore+=10
    else:
        pass
    result={'name':bowler['name'],'bowlscore':bowlscore}
    return result
